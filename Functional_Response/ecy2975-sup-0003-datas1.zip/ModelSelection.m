clear; clc;

[num text] = xlsread('FoRAGE db 10_14_19.csv','FoRAGE db 10_14_19'); 
    dataset_ID = num(:,1); 
    taxon = text(2:size(text,1),10);
    dim = num(:,4);
    field = text(2:size(text,1),5);
    aqua = text(2:size(text,1),6);
    cell = text(2:size(text,1),8);
    temp = num(:,24);
    mass = num(:,29);
    prey_mass = num(:,32);
    scr = num(:,52);
    ht = num(:,55);
    arena2D = num(:,27);
    arena3D = num(:,28);
    arena = arena3D;
    ratio = mass./prey_mass;
    AICtype3 = num(:,48); %read in AIC for type III equation
    AICtype2 = num(:,59); %read in AIC for type II equation
    AICdiff = AICtype2 - AICtype3; %calculate the difference in AICs 
    AICdiff3 = AICdiff(AICdiff>2); %identify the type III responses 
%For type III to be better than type II, type III needs to be at least 2 smaller than type II
count_ht = 0;
 %There's a natural break in the cloud of hts. Remove unrealistically small hts in this cloud   
    for i = 1:length(ht)
        if ht(i) <= 1E-6
            ht(i) = NaN;
        count_ht = count_ht + 1; %determine how many handling times we removed
        end
    end
 
 %Remove arena sizes for those that were done in the field
    field_check = NaN(length(field),1);
    for i = 1:length(field)
        field_check(i,1) = contains(field(i),"field");
            if field_check(i,1) == 1
               arena2D(i) = NaN;
               arena3D(i) = NaN;
            end
    end    
 
temp(ismember(taxon,'Mammal')) = 37;
temp(ismember(taxon,'Bird')) = 42;
    
%Make one thing with all arena sizes regardless of dimensionality
    for i = 1:length(arena)
        if dim(i) == 2 %2D FRs get 2D arena size
            arena(i) = arena2D(i);      
        elseif dim(i) == 2.5 %2.5D FRs get 3D AS if available and 2D if not available
            if isnan(arena3D(i))
                arena(i) = arena2D(i);
            else
                arena(i) = arena3D(i);
            end
        elseif dim(i) ==3 %3D FRs get 3D AS
            arena(i) = arena3D(i);
        end
    end    
    
    %%
    ds = dataset(dataset_ID,taxon,dim,log(ratio),log(mass),log(prey_mass),temp,log(scr),log(ht),log(arena),aqua,cell,AICdiff,AICtype2,AICtype3,... %Use for handling time
    'VarNames',{'ID','Taxon','Dim','logMR','logPred','logPrey','Temp','logSCR','logHT','logAS','Aqua','Cell','AICdiff','AIC2','AIC3'});

    %ds = ds(ds.AICdiff<2,:); %Uncomment to take out the FRs that are type III

    ds_corr = dataset(log(ratio),temp,log(scr),log(ht),log(arena2D),log(arena3D),...
    'VarNames',{'logMR','Temp','logSCR','logHT','loga2D','loga3D'});
    
    %[R,PValue] = corrplot(ds_corr,'testR','on'); % correlation matrix
    
    
    
    %% Separate out dimensions
    
    %To find the number of FRs in each taxa:
    [C,ia,ic] = unique(taxon);
    a_counts = accumarray(ic,1);
    
    %Use for space clearance rate only   
    ds2 = ds(ds.Dim == 2,:);
    ds25 = ds(ds.Dim == 2.5,:);
    ds3 = ds(ds.Dim == 3,:);
    
    %Pull out the taxa with fewer than 10 FRs   
    ds_taxa = ds(~ismember(ds.Taxon,'Amphibian'),:);
    ds_taxa = ds_taxa(~ismember(ds_taxa.Taxon,'Chrysophyte'),:);   
    ds_taxa = ds_taxa(~ismember(ds_taxa.Taxon,'Euglenid'),:);    
    ds_taxa = ds_taxa(~ismember(ds_taxa.Taxon,'Platyhelminth'),:);    
    ds_taxa = ds_taxa(~ismember(ds_taxa.Taxon,'Reptile'),:);    
    ds_taxa = ds_taxa(~ismember(ds_taxa.Taxon,'Sarcodine'),:);    
    ds_taxa = ds_taxa(~ismember(ds_taxa.Taxon,'Tardigrade'),:);
    ds_taxa = ds_taxa(~ismember(ds_taxa.Taxon,'Plant'),:);
    ds_taxa = ds_taxa(~ismember(ds_taxa.Taxon,'Bird'),:);
    ds_taxa = ds_taxa(~ismember(ds_taxa.Taxon,'Mammal'),:);
    ds_taxa = ds_taxa(~ismember(ds_taxa.Taxon,'Mollusk'),:);

    ds_aqua = ds(~ismember(ds.Aqua,'Mixed'),:);
    
    %Use these datasets to look at effects of taxon. 
    ds2_taxa = ds_taxa(ds_taxa.Dim == 2,:);
    ds25_taxa = ds_taxa(ds_taxa.Dim == 2.5,:);
    ds3_taxa = ds_taxa(ds_taxa.Dim == 3,:);  
    
    ds2_taxa = ds2_taxa(~ismember(ds2_taxa.Taxon,'Mollusk'),:);   
    ds2_taxa = ds2_taxa(~ismember(ds2_taxa.Taxon,'Cnidarian'),:); 
    ds2_taxa = ds2_taxa(~ismember(ds2_taxa.Taxon,'Mammal'),:);
    ds2_taxa = ds2_taxa(~ismember(ds2_taxa.Taxon,'Bird'),:);
    ds25_taxa = ds25_taxa(~ismember(ds25_taxa.Taxon,'Mollusk'),:);
    ds3_taxa = ds3_taxa(~ismember(ds3_taxa.Taxon,'Bird'),:);
    ds3_aqua = ds3(~ismember(ds3.Aqua,'Mixed'),:);
    

    %% 2 dimensional, space clearance rate
    %Test linear vs quadratic model for each one
    %Dont have enough data to add taxon as a predictor for 2 or 3D and look at quadratic, so will
    %use ds_taxa datasets
    
    AIC2 = NaN(18,1);
    
    %With all three (I'm not including temp as an optional predictor variable, since that is what we're interested in)
    lm_scr_2 = fitlme(ds2,'logSCR ~ logPrey + logPred + Temp^2 + logAS + (1|Taxon)')
    test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(1,1) = cell2mat(test(2,1));  
    lm_scr_2 = fitlme(ds2,'logSCR ~ logPrey + logPred + Temp + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(2,1) = cell2mat(test(2,1));
    
    %With two of three
    lm_scr_2 = fitlme(ds2,'logSCR ~ logPred + Temp^2 + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(3,1) = cell2mat(test(2,1));
    lm_scr_2 = fitlme(ds2,'logSCR ~ logPred + Temp + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(4,1) = cell2mat(test(2,1));
    
    lm_scr_2 = fitlme(ds2,'logSCR ~ logPrey + Temp^2 + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(5,1) = cell2mat(test(2,1));
    lm_scr_2 = fitlme(ds2,'logSCR ~ logPrey + Temp + logAS + (1|Taxon)');test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(6,1) = cell2mat(test(2,1));   
    
    lm_scr_2 = fitlme(ds2,'logSCR ~ logPrey + logPred + Temp^2 + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(7,1) = cell2mat(test(2,1));
    lm_scr_2 = fitlme(ds2,'logSCR ~ logPrey + logPred + Temp + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(8,1) = cell2mat(test(2,1));
    
    %With one of three
    lm_scr_2 = fitlme(ds2,'logSCR ~ Temp^2 + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(9,1) = cell2mat(test(2,1));
    lm_scr_2 = fitlme(ds2,'logSCR ~ Temp + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(10,1) = cell2mat(test(2,1));   
    
    lm_scr_2 = fitlme(ds2,'logSCR ~ logPrey + Temp^2 + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(11,1) = cell2mat(test(2,1));
    lm_scr_2 = fitlme(ds2,'logSCR ~ logPrey + Temp + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(12,1) = cell2mat(test(2,1));
    
    lm_scr_2 = fitlme(ds2,'logSCR ~ logPred + Temp^2 + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(13,1) = cell2mat(test(2,1));
    lm_scr_2 = fitlme(ds2,'logSCR ~ logPred + Temp + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(14,1) = cell2mat(test(2,1));
    
    %With just temp  
    lm_scr_2 = fitlme(ds2,'logSCR ~ Temp^2 + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(15,1) = cell2mat(test(2,1));
    lm_scr_2 = fitlme(ds2,'logSCR ~ Temp + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(16,1) = cell2mat(test(2,1));
    
    %Best model (considering only lowest AIC, not whether everything is significant) without the random taxon effect
    lm_scr_2 = fitlme(ds2,'logSCR ~ logPrey + logPred + Temp^2 + logAS'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(17,1) = cell2mat(test(2,1));
    
    %Best model using mass ratio instead of pred and prey mass
    lm_scr_2 = fitlme(ds2,'logSCR ~ logMR + Temp^2 + logAS + (1|Taxon)')
    test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC2(18,1) = cell2mat(test(2,1));  
    
    %% 2.5 dimensional, space clearance rate
    AIC25 = NaN(18,1);
    
    %With all three (I'm not including temp as an optional predictor variable, since that is what we're interested in)
    lm_scr_2 = fitlme(ds25,'logSCR ~ logPrey + logPred + Temp^2 + logAS + (1|Taxon)')
    test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(1,1) = cell2mat(test(2,1));
    lm_scr_2 = fitlme(ds25,'logSCR ~ logPrey + logPred + Temp + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(2,1) = cell2mat(test(2,1));
    
    %With two of three
    lm_scr_2 = fitlme(ds25,'logSCR ~ logPred + Temp^2 + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(3,1) = cell2mat(test(2,1));
    lm_scr_2 = fitlme(ds25,'logSCR ~ logPred + Temp + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(4,1) = cell2mat(test(2,1));
    
    lm_scr_2 = fitlme(ds25,'logSCR ~ logPrey + Temp^2 + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(5,1) = cell2mat(test(2,1));
    lm_scr_2 = fitlme(ds25,'logSCR ~ logPrey + Temp + logAS + (1|Taxon)');test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(6,1) = cell2mat(test(2,1));   
    
    lm_scr_2 = fitlme(ds25,'logSCR ~ logPrey + logPred + Temp^2 + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(7,1) = cell2mat(test(2,1));
    lm_scr_2 = fitlme(ds25,'logSCR ~ logPrey + logPred + Temp + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(8,1) = cell2mat(test(2,1));
    
    %With one of three
    lm_scr_2 = fitlme(ds25,'logSCR ~ Temp^2 + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(9,1) = cell2mat(test(2,1));
    lm_scr_2 = fitlme(ds25,'logSCR ~ Temp + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(10,1) = cell2mat(test(2,1));   
    
    lm_scr_2 = fitlme(ds25,'logSCR ~ logPrey + Temp^2 + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(11,1) = cell2mat(test(2,1));
    lm_scr_2 = fitlme(ds25,'logSCR ~ logPrey + Temp + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(12,1) = cell2mat(test(2,1));
    
    lm_scr_2 = fitlme(ds25,'logSCR ~ logPred + Temp^2 + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(13,1) = cell2mat(test(2,1));
    lm_scr_2 = fitlme(ds25,'logSCR ~ logPred + Temp + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(14,1) = cell2mat(test(2,1));
    
    %With just temp  
    lm_scr_2 = fitlme(ds25,'logSCR ~ Temp^2 + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(15,1) = cell2mat(test(2,1));
    lm_scr_2 = fitlme(ds25,'logSCR ~ Temp + (1|Taxon)'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(16,1) = cell2mat(test(2,1));
    
    %Best model (considering only lowest AIC, not whether everything is significant) without the random taxon effect
    lm_scr_2 = fitlme(ds25,'logSCR ~ logPrey + logPred + Temp^2 + logAS'); test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(17,1) = cell2mat(test(2,1));
        
    %Best model using mass ratio instead of pred and prey mass
    lm_scr_2 = fitlme(ds25,'logSCR ~ logMR + Temp^2 + logAS + (1|Taxon)')
    test = dataset2cell(lm_scr_2.ModelCriterion(1,1)); AIC25(18,1) = cell2mat(test(2,1));  
    
     %% 3 dimensional, space clearance rate
    AIC3 = NaN(18,1);
    
    %With all three (I'm not including temp as an optional predictor variable, since that is what we're interested in)
    lm_scr_3 = fitlme(ds3,'logSCR ~ logPrey + logPred + Temp^2 + logAS + (1|Taxon)')
    test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(1,1) = cell2mat(test(2,1));
    lm_scr_3 = fitlme(ds3,'logSCR ~ logPrey + logPred + Temp + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(2,1) = cell2mat(test(2,1));
    
    %With two of three
    lm_scr_3 = fitlme(ds3,'logSCR ~ logPred + Temp^2 + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(3,1) = cell2mat(test(2,1));
    lm_scr_3 = fitlme(ds3,'logSCR ~ logPred + Temp + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(4,1) = cell2mat(test(2,1));
    
    lm_scr_3 = fitlme(ds3,'logSCR ~ logPrey + Temp^2 + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(5,1) = cell2mat(test(2,1));
    lm_scr_3 = fitlme(ds3,'logSCR ~ logPrey + Temp + logAS + (1|Taxon)');test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(6,1) = cell2mat(test(2,1));   
    
    lm_scr_3 = fitlme(ds3,'logSCR ~ logPrey + logPred + Temp^2 + (1|Taxon)'); test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(7,1) = cell2mat(test(2,1));
    lm_scr_3 = fitlme(ds3,'logSCR ~ logPrey + logPred + Temp + (1|Taxon)'); test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(8,1) = cell2mat(test(2,1));
    
    %With one of three
    lm_scr_3 = fitlme(ds3,'logSCR ~ Temp^2 + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(9,1) = cell2mat(test(2,1));
    lm_scr_3 = fitlme(ds3,'logSCR ~ Temp + logAS + (1|Taxon)'); test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(10,1) = cell2mat(test(2,1));   
    
    lm_scr_3 = fitlme(ds3,'logSCR ~ logPrey + Temp^2 + (1|Taxon)'); test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(11,1) = cell2mat(test(2,1));
    lm_scr_3 = fitlme(ds3,'logSCR ~ logPrey + Temp + (1|Taxon)'); test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(12,1) = cell2mat(test(2,1));
    
    lm_scr_3 = fitlme(ds3,'logSCR ~ logPred + Temp^2 + (1|Taxon)'); test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(13,1) = cell2mat(test(2,1));
    lm_scr_3 = fitlme(ds3,'logSCR ~ logPred + Temp + (1|Taxon)'); test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(14,1) = cell2mat(test(2,1));
    
    %With just temp  
    lm_scr_3 = fitlme(ds3,'logSCR ~ Temp^2 + (1|Taxon)'); test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(15,1) = cell2mat(test(2,1));
    lm_scr_3 = fitlme(ds3,'logSCR ~ Temp + (1|Taxon)'); test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(16,1) = cell2mat(test(2,1));
    
    %Best model (considering only lowest AIC, not whether everything is significant) without the random taxon effect
    lm_scr_3 = fitlme(ds3,'logSCR ~ logPrey + logPred + Temp^2 + logAS'); test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(17,1) = cell2mat(test(2,1));
        
    %Best model using mass ratio instead of pred and prey mass
    lm_scr_3 = fitlme(ds3,'logSCR ~ logMR + Temp^2 + logAS + (1|Taxon)')
    test = dataset2cell(lm_scr_3.ModelCriterion(1,1)); AIC3(18,1) = cell2mat(test(2,1));  
    
    %% all dimensions, handling time
    
    AIC_ht = NaN(34,1);
    
    %With all four
    lm_ht = fitlme(ds,'logHT ~ logPred + logPrey + logAS + Dim + Temp^2 + (1|Taxon)')
    test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(1,1) = cell2mat(test(2,1));  
    lm_ht = fitlme(ds,'logHT ~ logPred + logPrey + logAS + Dim + Temp + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(2,1) = cell2mat(test(2,1)); 
 
    %With three of four
    lm_ht = fitlme(ds,'logHT ~ logPrey + logAS + Dim + Temp^2 + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(3,1) = cell2mat(test(2,1));  
    lm_ht = fitlme(ds,'logHT ~ logPrey + logAS + Dim + Temp + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(4,1) = cell2mat(test(2,1)); 

    lm_ht = fitlme(ds,'logHT ~ logPred + logAS + Dim + Temp^2 + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(5,1) = cell2mat(test(2,1));  
    lm_ht = fitlme(ds,'logHT ~ logPred + logAS + Dim + Temp + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(6,1) = cell2mat(test(2,1)); 
    
    lm_ht = fitlme(ds,'logHT ~ logPred + logPrey + Dim + Temp^2 + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(7,1) = cell2mat(test(2,1));  
    lm_ht = fitlme(ds,'logHT ~ logPred + logPrey + Dim + Temp + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(8,1) = cell2mat(test(2,1)); 

    lm_ht = fitlme(ds,'logHT ~ logPred + logPrey + logAS + Temp^2 + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(9,1) = cell2mat(test(2,1));  
    lm_ht = fitlme(ds,'logHT ~ logPred + logPrey + logAS + Temp + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(10,1) = cell2mat(test(2,1)); 
   
    %With two of four
    lm_ht = fitlme(ds,'logHT ~ logAS + Dim + Temp^2 + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(11,1) = cell2mat(test(2,1));  
    lm_ht = fitlme(ds,'logHT ~ logAS + Dim + Temp + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(12,1) = cell2mat(test(2,1)); 

    lm_ht = fitlme(ds,'logHT ~ logPrey + Dim + Temp^2 + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(13,1) = cell2mat(test(2,1));  
    lm_ht = fitlme(ds,'logHT ~ logPrey + Dim + Temp + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(14,1) = cell2mat(test(2,1)); 

    lm_ht = fitlme(ds,'logHT ~ logPrey + logAS + Temp^2 + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(15,1) = cell2mat(test(2,1));  
    lm_ht = fitlme(ds,'logHT ~ logPrey + logAS + Temp + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(16,1) = cell2mat(test(2,1)); 
   
    lm_ht = fitlme(ds,'logHT ~ logPred + Dim + Temp^2 + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(17,1) = cell2mat(test(2,1));  
    lm_ht = fitlme(ds,'logHT ~ logPred + Dim + Temp + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(18,1) = cell2mat(test(2,1)); 
    
    lm_ht = fitlme(ds,'logHT ~ logPred + logAS + Temp^2 + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(19,1) = cell2mat(test(2,1));  
    lm_ht = fitlme(ds,'logHT ~ logPred + logAS + Temp + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(20,1) = cell2mat(test(2,1)); 
    
    lm_ht = fitlme(ds,'logHT ~ logPred + logPrey + Temp^2 + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(21,1) = cell2mat(test(2,1));  
    lm_ht = fitlme(ds,'logHT ~ logPred + logPrey + Temp + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(22,1) = cell2mat(test(2,1)); 
    
    %With one of four
    lm_ht = fitlme(ds,'logHT ~ Dim + Temp^2 + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(23,1) = cell2mat(test(2,1));  
    lm_ht = fitlme(ds,'logHT ~ Dim + Temp + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(24,1) = cell2mat(test(2,1)); 
    
    lm_ht = fitlme(ds,'logHT ~ logAS + Temp^2 + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(25,1) = cell2mat(test(2,1));  
    lm_ht = fitlme(ds,'logHT ~ logAS + Temp + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(26,1) = cell2mat(test(2,1)); 
    
    lm_ht = fitlme(ds,'logHT ~ logPrey + Temp^2 + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(27,1) = cell2mat(test(2,1));  
    lm_ht = fitlme(ds,'logHT ~ logPrey + Temp + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(28,1) = cell2mat(test(2,1)); 
    
    lm_ht = fitlme(ds,'logHT ~ logPred + Temp^2 + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(29,1) = cell2mat(test(2,1));  
    lm_ht = fitlme(ds,'logHT ~ logPred + Temp + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(30,1) = cell2mat(test(2,1)); 
    
    %With just temp
    lm_ht = fitlme(ds,'logHT ~ Temp^2 + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(31,1) = cell2mat(test(2,1));  
    lm_ht = fitlme(ds,'logHT ~ Temp + (1|Taxon)');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(32,1) = cell2mat(test(2,1)); 
    
    %Best model (considering only lowest AIC, not whether everything is significant) without the random taxon effect
    lm_ht = fitlme(ds,'logHT ~ logPred + logPrey + logAS + Dim + Temp^2');test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(33,1) = cell2mat(test(2,1));  
    
    %Best model using mass ratio instead of pred and prey mass
    lm_ht = fitlme(ds,'logHT ~ logMR + logAS + Dim + Temp^2 + (1|Taxon)')
    test = dataset2cell(lm_ht.ModelCriterion(1,1)); AIC_ht(34,1) = cell2mat(test(2,1)); 
    
%% 2 dimensional, To account for colinearity bw pred mass and AS
 
 lm_AS_2 = fitlme(ds2,'logPred ~ logAS'); Resids2 = residuals(lm_AS_2);%Do a regression bw mass and AS to see if pred is big for its AS, and pull resids from that model
 ds_resids2 = dataset(Resids2,'VarNames',{'Resids2'});%put resids into dataset format so it can be added to ds2
 ds2res = [ds2(:,:) ds_resids2(:,:)]; %add resids column to ds2
 lm_resids_2 = fitlme(ds2res,'logSCR ~ logPrey + Resids2 + Temp^2 + logAS + (1|Taxon)')%Use resids in place of pred mass in best model (and remove AS)
 
 %% 2.5 dimensional, To account for colinearity bw pred mass and AS
 
 lm_AS_25 = fitlme(ds25,'logPred ~ logAS'); Resids25 = residuals(lm_AS_25);
 ds_resids25 = dataset(Resids25,'VarNames',{'Resids25'});
 ds25res = [ds25(:,:) ds_resids25(:,:)];
 lm_resids_25 = fitlme(ds25res,'logSCR ~ logPrey + logAS + Resids25 + Temp^2 + logAS + (1|Taxon)')
 
 %% 3 dimensional, To account for colinearity bw pred mass and AS
 
 lm_AS_3 = fitlme(ds3,'logPred ~ logAS'); Resids3 = residuals(lm_AS_3);
 ds_resids3 = dataset(Resids3,'VarNames',{'Resids3'});
 ds3res = [ds3(:,:) ds_resids3(:,:)];
 lm_resids_3 = fitlme(ds3res,'logSCR ~ logPrey + Resids3 + Temp^2 + logAS + (1|Taxon)')

  %% %use to see how many FRs are used in each analysis %This part was not included on the code submitted with the manuscript (I believe)
 ds_taxa1 = ds_taxa(~isnan(ds_taxa.logHT),:);
 ds_taxa2 = ds_taxa1(~isnan(ds_taxa1.logPred),:);
 ds_taxafinal = ds_taxa2(ismember(ds_taxa2.Taxon,'Arachnid'),:);
 
 
  %% Partial regression plot for 2D SCR and TEMPERATURE.
 
 % full model residuals
lm_scr_2qa = fitlme(ds2,'logSCR ~ logPrey + logPred + Temp^2 + logAS + (1|Taxon)');Rfull = residuals(lm_scr_2qa);

figure(1);clf(1);
subplot(331);
    box on; hold on;

    output = dataset2cell(lm_scr_2qa.Coefficients(6,2)); %get coefficient for temperature squared
    beta_temp2 = cell2mat(output(2)); % get coefficient out of structure
    output = dataset2cell(lm_scr_2qa.Coefficients(4,2));  %get linear coefficient for temperature
    beta_temp = cell2mat(output(2));
    partials = Rfull + beta_temp2.*(ds2.Temp.^2) + beta_temp.*(ds2.Temp); % calculate the actual effect of predictor
    d = dataset(ds2.Temp,partials); % combine partial and predictor into data set
    d = d(~isnan(partials),:); % take out nans case
    
    optimum2SCR = -beta_temp/(2*beta_temp2);    %calculate vertex of parabola

    pr_scr_pm = fitlm(d,'Var2 ~ Var1^2'); % get new fit between predictor and partial
    Xnew = nanmin(d.Var1):1e-1:nanmax(d.Var1); % new x data
    [p_1, ci_1] = predict(pr_scr_pm,Xnew'); % predict fitted line and ci's
    xlim([-2 38]);
    ylim([-8 6]);
    
    %plot(d.Var1,d.Var2,'ok','MarkerFaceColor','w'); %plots SOLID colored points
    
    scatter1 = scatter(d.Var1,d.Var2,18,'MarkerFaceColor',1/255*[15 32 128],'MarkerEdgeColor','w'); %plots TRANSLUCENT points
    % Set property MarkerFaceAlpha and MarkerEdgeAlpha to <1.0
    scatter1.MarkerFaceAlpha = .3;
    scatter1.MarkerEdgeAlpha = .3;
    
    plot(Xnew,p_1,'-k');
    jbfill(Xnew,ci_1(:,2)',ci_1(:,1)',[0.5 0.5 0.5],'w',1,0.2);
    ylabel('2D');

    pval = dataset2cell(lm_scr_2qa.Coefficients(6,6)); %pull out the pvalue for the slope (or curve for temp2)
    pval2 = cell2mat(pval(2)); %get out of structure
    round_pval = round(pval2,3); %round to nearest 3 places to the right of the decimal
    if round_pval == 0
        pval3 = '<0.001'; %if pvalue is zero, change to less than 0.00005
    else pval3 = num2str(round_pval);  %convert to a string
    end
    pvalue = ['{\itp} = ' pval3]; %add p= to the string
%     gtext(pvalue,'FontSize',9); %plot on figure

    %% Partial regression plot for 2D SCR and PREDATOR mass.
 
 % full model residuals
 figure(1);
lm_scr_2qa = fitlme(ds2,'logSCR ~ logPrey + logPred + Temp^2 + logAS + (1|Taxon)');Rfull = residuals(lm_scr_2qa);

subplot(332); % partial regression plot for mopt and mass
    box on; hold on;

    output = dataset2cell(lm_scr_2qa.Coefficients(2,2)); % pull out coefficients (estimate for PM)
    beta_mass = cell2mat(output(2)); % get coefficient out of structure
    partials = Rfull + beta_mass.*ds2.logPred; % calculate the actual effect of predictor
    d = dataset(ds2.logPred,partials); % combine partial and predictor into data set
    d = d(~isnan(partials),:); % take out nans case
    
    pr_scr_pm = fitlm(d,'Var2 ~ Var1'); % get new fit between predictor and partial
    Xnew = nanmin(d.Var1):1e-1:nanmax(d.Var1); % new x data
    [p_1, ci_1] = predict(pr_scr_pm,Xnew'); % predict fitted line and ci's

%    plot(d.Var1,d.Var2,'ok','MarkerFaceColor','w'); %plots SOLID colored points

    scatter1 = scatter(d.Var1,d.Var2,18,'MarkerFaceColor',1/255*[15 32 128],'MarkerEdgeColor','w'); %plots TRANSLUCENT points
    % Set property MarkerFaceAlpha and MarkerEdgeAlpha to <1.0
    scatter1.MarkerFaceAlpha = .3;
    scatter1.MarkerEdgeAlpha = .3;
    
    plot(Xnew,p_1,'-k');
    jbfill(Xnew,ci_1(:,2)',ci_1(:,1)',[0.5 0.5 0.5],'w',1,0.2);
    xlim([-8 16]);
   
    pval = dataset2cell(lm_scr_2qa.Coefficients(2,6)); %pull out the pvalue for the slope (or curve for temp2)
    pval2 = cell2mat(pval(2)); %get out of structure
    round_pval = round(pval2,3); %round to nearest 3 places to the right of the decimal
    if round_pval == 0
        pval3 = '<0.001'; %if pvalue is zero, change to less than 0.00005
    else pval3 = num2str(round_pval);  %convert to a string
    end
    pvalue = ['{\itp} = ' pval3]; %add p= to the string
%     gtext(pvalue,'FontSize',9); %plot on figure

        %% Partial regression plot for 2D SCR and PREY mass.
 
 % full model residuals
 figure(1);
lm_scr_2qa = fitlme(ds2,'logSCR ~ logPrey + logPred + Temp^2 + logAS + (1|Taxon)');Rfull = residuals(lm_scr_2qa);

subplot(333); % partial regression plot for mopt and mass
    box on; hold on;

    output = dataset2cell(lm_scr_2qa.Coefficients(3,2)); % pull out coefficients (estimate for PM)
    beta_mass = cell2mat(output(2)); % get coefficient out of structure
    partials = Rfull + beta_mass.*ds2.logPrey; % calculate the actual effect of predictor
    d = dataset(ds2.logPrey,partials); % combine partial and predictor into data set
    d = d(~isnan(partials),:); % take out nans case
    
    pr_scr_pm = fitlm(d,'Var2 ~ Var1'); % get new fit between predictor and partial
    Xnew = nanmin(d.Var1):1e-1:nanmax(d.Var1); % new x data
    [p_1, ci_1] = predict(pr_scr_pm,Xnew'); % predict fitted line and ci's

%    plot(d.Var1,d.Var2,'ok','MarkerFaceColor','w'); %plots SOLID colored points

    scatter1 = scatter(d.Var1,d.Var2,18,'MarkerFaceColor',1/255*[15 32 128],'MarkerEdgeColor','w'); %plots TRANSLUCENT points
    % Set property MarkerFaceAlpha and MarkerEdgeAlpha to <1.0
    scatter1.MarkerFaceAlpha = .3;
    scatter1.MarkerEdgeAlpha = .3;
    
    plot(Xnew,p_1,'-k');
    jbfill(Xnew,ci_1(:,2)',ci_1(:,1)',[0.5 0.5 0.5],'w',1,0.2);
    xlim([-8 10]);
        
    pval = dataset2cell(lm_scr_2qa.Coefficients(3,6)); %pull out the pvalue for the slope (or curve for temp2)
    pval2 = cell2mat(pval(2)); %get out of structure
    round_pval = round(pval2,3); %round to nearest 3 places to the right of the decimal
    if round_pval == 0
        pval3 = '<0.001'; %if pvalue is zero, change to less than 0.00005
    else pval3 = num2str(round_pval);  %convert to a string
    end
    pvalue = ['{\itp} = ' pval3]; %add p= to the string
%     gtext(pvalue,'FontSize',9); %plot on figure    
    
     %% Partial regression plot for 2.5D SCR and TEMPERATURE.
 
 % full model residuals
    lm_scr_25qa = fitlme(ds25,'logSCR ~ logPrey + logPred + Temp^2 + logAS + (1|Taxon)');Rfull = residuals(lm_scr_25qa);

figure(1);
subplot(334)
    box on; hold on;

    output = dataset2cell(lm_scr_25qa.Coefficients(6,2)); %get coefficient for temperature squared
    beta_temp2 = cell2mat(output(2)); % get coefficient out of structure
    output = dataset2cell(lm_scr_25qa.Coefficients(4,2));  %get linear coefficient for temperature
    beta_temp = cell2mat(output(2));
    partials = Rfull + beta_temp2.*(ds25.Temp).^2 + beta_temp.*(ds25.Temp); % calculate the actual effect of predictor
    d = dataset(ds25.Temp,partials); % combine partial and predictor into data set
    d = d(~isnan(partials),:); % take out nans case
    
    optimum25SCR = -beta_temp/(2*beta_temp2);    %calculate vertex of parabola

    pr_scr_pm = fitlm(d,'Var2 ~ Var1^2'); % get new fit between predictor and partial
    Xnew = nanmin(d.Var1):1e-1:nanmax(d.Var1); % new x data
    [p_1, ci_1] = predict(pr_scr_pm,Xnew'); % predict fitted line and ci's
    ylim([0.8 9]);
    xlim([3.5 37.5]);
    ylabel('2.5D');
    %plot(d.Var1,d.Var2,'ok','MarkerFaceColor','w'); %plots SOLID colored points
    
    scatter1 = scatter(d.Var1,d.Var2,18,'MarkerFaceColor',1/255*[169 90 161],'MarkerEdgeColor','w'); %plots TRANSLUCENT points
    % Set property MarkerFaceAlpha and MarkerEdgeAlpha to <1.0
    scatter1.MarkerFaceAlpha = .3;
    scatter1.MarkerEdgeAlpha = .3;
    
    plot(Xnew,p_1,'-k');
    jbfill(Xnew,ci_1(:,2)',ci_1(:,1)',[0.5 0.5 0.5],'w',1,0.2);    

    pval = dataset2cell(lm_scr_25qa.Coefficients(6,6)); %pull out the pvalue for the slope (or curve for temp2)
    pval2 = cell2mat(pval(2)); %get out of structure
    round_pval = round(pval2,3); %round to nearest 3 places to the right of the decimal
    if round_pval == 0
        pval3 = '<0.001'; %if pvalue is zero, change to less than 0.00005
    else pval3 = num2str(round_pval);  %convert to a string
    end
    pvalue = ['{\itp} = ' pval3]; %add p= to the string
%     gtext(pvalue,'FontSize',9); %plot on figure
    
    %% Partial regression plot for 2.5D SCR and PREDATOR mass.
 
 % full model residuals
    lm_scr_25qa = fitlme(ds25,'logSCR ~ logPrey + logPred + Temp^2 + logAS + (1|Taxon)');Rfull = residuals(lm_scr_25qa);

figure(1);
subplot(335)
    box on; hold on;

    output = dataset2cell(lm_scr_25qa.Coefficients(2,2));
    beta_mass = cell2mat(output(2)); % get coefficient out of structure
    partials = Rfull + beta_mass.*ds25.logPred; % calculate the actual effect of predictor
    d = dataset(ds25.logPred,partials); % combine partial and predictor into data set
    d = d(~isnan(partials),:); % take out nans case
    
    pr_scr_pm = fitlm(d,'Var2 ~ Var1'); % get new fit between predictor and partial
    Xnew = nanmin(d.Var1):1e-1:nanmax(d.Var1); % new x data
    [p_1, ci_1] = predict(pr_scr_pm,Xnew'); % predict fitted line and ci's
    
    xlim([-3.5 10.5]);
    
    %plot(d.Var1,d.Var2,'ok','MarkerFaceColor','w');%plots SOLID colored points

    scatter1 = scatter(d.Var1,d.Var2,18,'MarkerFaceColor',1/255*[169 90 161],'MarkerEdgeColor','w'); %plots TRANSLUCENT points
    % Set property MarkerFaceAlpha and MarkerEdgeAlpha to <1.0
    scatter1.MarkerFaceAlpha = .3;
    scatter1.MarkerEdgeAlpha = .3;
    
    plot(Xnew,p_1,'-k');
    jbfill(Xnew,ci_1(:,2)',ci_1(:,1)',[0.5 0.5 0.5],'w',1,0.2);   

    pval = dataset2cell(lm_scr_25qa.Coefficients(2,6)); %pull out the pvalue for the slope (or curve for temp2)
    pval2 = cell2mat(pval(2)); %get out of structure
    round_pval = round(pval2,3); %round to nearest 3 places to the right of the decimal
    if round_pval == 0
        pval3 = '<0.001'; %if pvalue is zero, change to less than 0.00005
    else pval3 = num2str(round_pval);  %convert to a string
    end
    pvalue = ['{\itp} = ' pval3]; %add p= to the string
%     gtext(pvalue,'FontSize',9); %plot on figure
    
    %% Partial regression plot for 2.5D SCR and PREY mass.
 
 % full model residuals
    lm_scr_25qa = fitlme(ds25,'logSCR ~ logPrey + logPred + Temp^2 + logAS + (1|Taxon)');Rfull = residuals(lm_scr_25qa);

figure(1);
subplot(336)
    box on; hold on;

    output = dataset2cell(lm_scr_25qa.Coefficients(3,2));
    beta_mass = cell2mat(output(2)); % get coefficient out of structure
    partials = Rfull + beta_mass.*ds25.logPrey; % calculate the actual effect of predictor
    d = dataset(ds25.logPrey,partials); % combine partial and predictor into data set
    d = d(~isnan(partials),:); % take out nans case
    
    pr_scr_pm = fitlm(d,'Var2 ~ Var1'); % get new fit between predictor and partial
    Xnew = nanmin(d.Var1):1e-1:nanmax(d.Var1); % new x data
    [p_1, ci_1] = predict(pr_scr_pm,Xnew'); % predict fitted line and ci's
    
    xlim([-3.5 5.5]);
    
    %plot(d.Var1,d.Var2,'ok','MarkerFaceColor','w');%plots SOLID colored points

    scatter1 = scatter(d.Var1,d.Var2,18,'MarkerFaceColor',1/255*[169 90 161],'MarkerEdgeColor','w'); %plots TRANSLUCENT points
    % Set property MarkerFaceAlpha and MarkerEdgeAlpha to <1.0
    scatter1.MarkerFaceAlpha = .3;
    scatter1.MarkerEdgeAlpha = .3;
    
    plot(Xnew,p_1,'-k');
    jbfill(Xnew,ci_1(:,2)',ci_1(:,1)',[0.5 0.5 0.5],'w',1,0.2);   

    pval = dataset2cell(lm_scr_25qa.Coefficients(3,6)); %pull out the pvalue for the slope (or curve for temp2)
    pval2 = cell2mat(pval(2)); %get out of structure
    round_pval = round(pval2,3); %round to nearest 3 places to the right of the decimal
    if round_pval == 0
        pval3 = '<0.001'; %if pvalue is zero, change to less than 0.00005
    else pval3 = num2str(round_pval);  %convert to a string
    end
    pvalue = ['{\itp} = ' pval3]; %add p= to the string
%     gtext(pvalue,'FontSize',9); %plot on figure

     %% Partial regression plot for 3D SCR and TEMPERATURE.
 
 % full model residuals
     lm_scr_3qa = fitlme(ds3,'logSCR ~ logPrey + logPred + Temp^2 + logAS + (1|Taxon)');Rfull = residuals(lm_scr_3qa);

figure(1);
subplot(337)
    box on; hold on;

    output = dataset2cell(lm_scr_3qa.Coefficients(6,2)); %get coefficient for temperature squared
    beta_temp2 = cell2mat(output(2)); % get coefficient out of structure
    output = dataset2cell(lm_scr_3qa.Coefficients(4,2));  %get linear coefficient for temperature
    beta_temp = cell2mat(output(2));
    partials = Rfull + beta_temp2.*(ds3.Temp).^2 + beta_temp.*(ds3.Temp); % calculate the actual effect of predictor
    d = dataset(ds3.Temp,partials); % combine partial and predictor into data set
    d = d(~isnan(partials),:); % take out nans case
    
    optimum3SCR = -beta_temp/(2*beta_temp2);   %calculate vertex of parabola 
    
    pr_scr_pm = fitlm(d,'Var2 ~ Var1^2'); % get new fit between predictor and partial
    Xnew = nanmin(d.Var1):1e-1:nanmax(d.Var1); % new x data
    [p_1, ci_1] = predict(pr_scr_pm,Xnew'); % predict fitted line and ci's
     
    xlabel('Temperature (^oC)');
    ylabel('3D');
    xlim([0 42]);
    ylim([-10 18]);
    %plot(d.Var1,d.Var2,'ok','MarkerFaceColor','w'); %plots SOLID colored points
    
    scatter1 = scatter(d.Var1,d.Var2,18,'MarkerFaceColor',1/255*[245 121 58],'MarkerEdgeColor','w'); %plots TRANSLUCENT points
    % Set property MarkerFaceAlpha and MarkerEdgeAlpha to <1.0
    scatter1.MarkerFaceAlpha = .3;
    scatter1.MarkerEdgeAlpha = .3;
    
    plot(Xnew,p_1,'-k');
    jbfill(Xnew,ci_1(:,2)',ci_1(:,1)',[0.5 0.5 0.5],'w',1,0.2);

    pval = dataset2cell(lm_scr_3qa.Coefficients(6,6)); %pull out the pvalue for the slope (or curve for temp2)
    pval2 = cell2mat(pval(2)); %get out of structure
    round_pval = round(pval2,3); %round to nearest 3 places to the right of the decimal
    if round_pval == 0
        pval3 = '<0.001'; %if pvalue is zero, change to less than 0.00005
    else pval3 = num2str(round_pval);  %convert to a string
    end
    pvalue = ['{\itp} = ' pval3]; %add p= to the string
%     gtext(pvalue,'FontSize',9); %plot on figure

      %% Partial regression plot for 3D SCR and PREDATOR mass.

 % full model residuals
    lm_scr_3qa = fitlme(ds3,'logSCR ~ logPrey + logPred + Temp^2 + logAS + (1|Taxon)');Rfull = residuals(lm_scr_3qa);

figure(1);
subplot(338)
    box on; hold on;

    output = dataset2cell(lm_scr_3qa.Coefficients(2,2)); 
    beta_mass = cell2mat(output(2)); % get coefficient out of structure
    partials = Rfull + beta_mass.*ds3.logPred; % calculate the actual effect of predictor
    d = dataset(ds3.logPred,partials); % combine partial and predictor into data set
    d = d(~isnan(partials),:); % take out nans case
    
    pr_scr_pm = fitlm(d,'Var2 ~ Var1'); % get new fit between predictor and partial
    Xnew = nanmin(d.Var1):1e-1:nanmax(d.Var1); % new x data
    [p_1, ci_1] = predict(pr_scr_pm,Xnew'); % predict fitted line and ci's
    
    xlabel('ln(Consumer mass (mg))');
    xlim([-19 16]);
    
    %plot(d.Var1,d.Var2,'ok','MarkerFaceColor','w');%plots SOLID colored points

    scatter1 = scatter(d.Var1,d.Var2,18,'MarkerFaceColor',1/255*[245 121 58],'MarkerEdgeColor','w'); %plots TRANSLUCENT points
    % Set property MarkerFaceAlpha and MarkerEdgeAlpha to <1.0
    scatter1.MarkerFaceAlpha = .3;
    scatter1.MarkerEdgeAlpha = .3;
    
    plot(Xnew,p_1,'-k');
    jbfill(Xnew,ci_1(:,2)',ci_1(:,1)',[0.5 0.5 0.5],'w',1,0.2); 

    pval = dataset2cell(lm_scr_3qa.Coefficients(2,6)); %pull out the pvalue for the slope (or curve for temp2)
    pval2 = cell2mat(pval(2)); %get out of structure
    round_pval = round(pval2,3); %round to nearest 3 places to the right of the decimal
    if round_pval == 0
        pval3 = '<0.001'; %if pvalue is zero, change to less than 0.00005
    else pval3 = num2str(round_pval);  %convert to a string
    end %convert to a string
    pvalue = ['{\itp} = ' pval3]; %add p= to the string
%     gtext(pvalue,'FontSize',9); %plot on figure
    
      %% Partial regression plot for 3D SCR and PREY mass.

 % full model residuals
    lm_scr_3qa = fitlme(ds3,'logSCR ~ logPrey + logPred + Temp^2 + logAS + (1|Taxon)');Rfull = residuals(lm_scr_3qa);

figure(1);
subplot(339)
    box on; hold on;

    output = dataset2cell(lm_scr_3qa.Coefficients(3,2)); 
    beta_mass = cell2mat(output(2)); % get coefficient out of structure
    partials = Rfull + beta_mass.*ds3.logPrey; % calculate the actual effect of predictor
    d = dataset(ds3.logPrey,partials); % combine partial and predictor into data set
    d = d(~isnan(partials),:); % take out nans case
    
    pr_scr_pm = fitlm(d,'Var2 ~ Var1'); % get new fit between predictor and partial
    Xnew = nanmin(d.Var1):1e-1:nanmax(d.Var1); % new x data
    [p_1, ci_1] = predict(pr_scr_pm,Xnew'); % predict fitted line and ci's
    
    ylabel('3D');
    xlabel('ln(Resource mass(mg))');
    xlim([-19 11]);
    
    %plot(d.Var1,d.Var2,'ok','MarkerFaceColor','w');%plots SOLID colored points

    scatter1 = scatter(d.Var1,d.Var2,18,'MarkerFaceColor',1/255*[245 121 58],'MarkerEdgeColor','w'); %plots TRANSLUCENT points
    % Set property MarkerFaceAlpha and MarkerEdgeAlpha to <1.0
    scatter1.MarkerFaceAlpha = .3;
    scatter1.MarkerEdgeAlpha = .3;
    
    plot(Xnew,p_1,'-k');
    jbfill(Xnew,ci_1(:,2)',ci_1(:,1)',[0.5 0.5 0.5],'w',1,0.2);   

    pval = dataset2cell(lm_scr_3qa.Coefficients(3,6)); %pull out the pvalue for the slope (or curve for temp2)
    pval2 = cell2mat(pval(2)); %get out of structure
    round_pval = round(pval2,3); %round to nearest 3 places to the right of the decimal
    if round_pval == 0
        pval3 = '<0.001'; %if pvalue is zero, change to less than 0.00005
    else pval3 = num2str(round_pval);  %convert to a string
    end
    pvalue = ['{\itp} = ' pval3]; %add p= to the string
%     gtext(pvalue,'FontSize',9); %plot on figure
    
% gtext('A','FontSize',12);
% gtext('B','FontSize',12);
% gtext('C','FontSize',12);
% gtext('D','FontSize',12);
% gtext('E','FontSize',12);
% gtext('F','FontSize',12);
% gtext('G','FontSize',12);
% gtext('H','FontSize',12);
% gtext('I','FontSize',12);
gtext('Residual {\ita}','FontSize',9);

     %% Partial regression plot for handling time, all dimensions, temperature 
 % full model residuals
lm_ht_q = fitlme(ds,'logHT ~ logPred + logPrey + logAS + Dim + Temp^2 + (1|Taxon)');Rfull = residuals(lm_ht_q);

figure(2);clf(2);
subplot(131)
    box on; hold on;

    output = dataset2cell(lm_ht_q.Coefficients(7,2)); % pull out coefficients (estimate for PM)
    beta_temp2 = cell2mat(output(2)); % get coefficient out of structure
    output = dataset2cell(lm_ht_q.Coefficients(5,2)); % pull out coefficients (estimate for PM)
    beta_temp = cell2mat(output(2)); % get coefficient out of structure
    partials = Rfull + beta_temp2.*(ds.Temp).^2 + beta_temp.*(ds.Temp); % calculate the actual effect of predictor
    d = dataset(ds.Temp,partials); % combine partial and predictor into data set
    d = d(~isnan(partials),:); % take out nans case
    
    optimumHT = -beta_temp/(2*beta_temp2); %calculate vertex of parabola
    
    pr_scr_pm = fitlm(d,'Var2 ~ Var1^2'); % get new fit between predictor and partial
    Xnew = nanmin(d.Var1):1e-1:nanmax(d.Var1); % new x data
    [p_1, ci_1] = predict(pr_scr_pm,Xnew'); % predict fitted line and ci's

    %plot(d.Var1,d.Var2,'ok','MarkerFaceColor','w');
    scatter1 = scatter(d.Var1,d.Var2,18,'MarkerFaceColor','b','MarkerEdgeColor','w'); 
    % Set property MarkerFaceAlpha and MarkerEdgeAlpha to <1.0
    scatter1.MarkerFaceAlpha = .3;
    scatter1.MarkerEdgeAlpha = .3;

    plot(Xnew,p_1,'-k');
    jbfill(Xnew,ci_1(:,2)',ci_1(:,1)','b','w',1,0.15);
    xlim([-3 42]);
    xlabel('Temperature (^oC)');
    ylabel('Residual {\ith}');

        pval = dataset2cell(lm_ht_q.Coefficients(7,6)); %pull out the pvalue for the slope (or curve for temp2)
    pval2 = cell2mat(pval(2)); %get out of structure
    round_pval = round(pval2,3); %round to nearest 3 places to the right of the decimal
    if round_pval == 0
        pval3 = '<0.001'; %if pvalue is zero, change to less than 0.00005
    else pval3 = num2str(round_pval);  %convert to a string
    end
    pvalue = ['{\itp} = ' pval3]; %add p= to the string
    %gtext(pvalue,'FontSize',9); %plot on figure
    
     %% Partial regression plot for handling time, all dimensions, PREDATOR mass 
 % full model residuals
lm_ht_q = fitlme(ds,'logHT ~ logPred + logPrey + logAS + Dim + Temp^2 + (1|Taxon)');Rfull = residuals(lm_ht_q);

figure(2);
subplot(132)
    box on; hold on;

    output = dataset2cell(lm_ht_q.Coefficients(3,2)); % pull out coefficients (estimate for PM)
    beta_mass = cell2mat(output(2)); % get coefficient out of structure
    partials = Rfull + beta_mass.*ds.logPred; % calculate the actual effect of predictor
    d = dataset(ds.logPred,partials); % combine partial and predictor into data set
    d = d(~isnan(partials),:); % take out nans case
    
    pr_scr_pm = fitlm(d,'Var2 ~ Var1'); % get new fit between predictor and partial
    Xnew = nanmin(d.Var1):1e-1:nanmax(d.Var1); % new x data
    [p_1, ci_1] = predict(pr_scr_pm,Xnew'); % predict fitted line and ci's

    %plot(d.Var1,d.Var2,'ok','MarkerFaceColor','w');
    scatter1 = scatter(d.Var1,d.Var2,18,'MarkerFaceColor','b','MarkerEdgeColor','w'); 
    % Set property MarkerFaceAlpha and MarkerEdgeAlpha to <1.0
    scatter1.MarkerFaceAlpha = .3;
    scatter1.MarkerEdgeAlpha = .3;

    plot(Xnew,p_1,'-k');
    xlim([-19 16]); %adjusted for clarity (one outlier not shown with this x lim)
    jbfill(Xnew,ci_1(:,2)',ci_1(:,1)','b','w',1,0.15);
    xlabel('ln(Consumer mass (mg))');
    
    pval = dataset2cell(lm_ht_q.Coefficients(3,6)); %pull out the pvalue for the slope (or curve for temp2)
    pval2 = cell2mat(pval(2)); %get out of structure
    round_pval = round(pval2,3); %round to nearest 3 places to the right of the decimal
    if round_pval == 0
        pval3 = '<0.001'; %if pvalue is zero, change to less than 0.00005
    else pval3 = num2str(round_pval);  %convert to a string
    end
    pvalue = ['{\itp} = ' pval3]; %add p= to the string
    %gtext(pvalue,'FontSize',9); %plot on figure
        
     %% Partial regression plot for handling time, all dimensions, PREY mass 
 % full model residuals
lm_ht_q = fitlme(ds,'logHT ~ logPred + logPrey + logAS + Dim + Temp^2 + (1|Taxon)');Rfull = residuals(lm_ht_q);

figure(2);
subplot(133)
    box on; hold on;

    output = dataset2cell(lm_ht_q.Coefficients(4,2)); % pull out coefficients (estimate for PM)
    beta_mass = cell2mat(output(2)); % get coefficient out of structure
    partials = Rfull + beta_mass.*ds.logPred; % calculate the actual effect of predictor
    d = dataset(ds.logPrey,partials); % combine partial and predictor into data set
    d = d(~isnan(partials),:); % take out nans case
    
    pr_scr_pm = fitlm(d,'Var2 ~ Var1'); % get new fit between predictor and partial
    Xnew = nanmin(d.Var1):1e-1:nanmax(d.Var1); % new x data
    [p_1, ci_1] = predict(pr_scr_pm,Xnew'); % predict fitted line and ci's

    %plot(d.Var1,d.Var2,'ok','MarkerFaceColor','w');
    scatter1 = scatter(d.Var1,d.Var2,18,'MarkerFaceColor','b','MarkerEdgeColor','w'); 
    % Set property MarkerFaceAlpha and MarkerEdgeAlpha to <1.0
    scatter1.MarkerFaceAlpha = .3;
    scatter1.MarkerEdgeAlpha = .3;
        
    plot(Xnew,p_1,'-k');
    xlim([-24 12]); %adjusted for clarity (one outlier not shown with this x lim)
    jbfill(Xnew,ci_1(:,2)',ci_1(:,1)','b','w',1,0.15);
    xlabel('ln(Resource mass (mg))');
   
        pval = dataset2cell(lm_ht_q.Coefficients(4,6)); %pull out the pvalue for the slope (or curve for temp2)
    pval2 = cell2mat(pval(2)); %get out of structure
    round_pval = round(pval2,3); %round to nearest 3 places to the right of the decimal
    if round_pval == 0
        pval3 = '<0.001'; %if pvalue is zero, change to less than 0.00005
    else pval3 = num2str(round_pval);  %convert to a string
    end
    pvalue = ['{\itp} = ' pval3]; %add p= to the string
    gtext(pvalue,'FontSize',9); %plot on figure
 
%     gtext('A','FontSize',12);
%     gtext('B','FontSize',12);
%     gtext('C','FontSize',12);
    
    %% Interactive effects of taxon and temperature on SPACE CLEARANCE RATE
    %Look at how temperature affects different taxa differently
    Dimensions = [2 2.5 3];
    
    figure(3);clf(3);
    subplot(1,3,1);
    plot([0 0],[0 19],'color',[0.5,0.5,0.5],'LineWidth',1,'LineStyle','--');hold on; %plot the dashed grey line at zero
    
    for k = 1:3     %Do once for each dimension

    if k == 1
      ds_focal_dim = ds2_taxa;
    elseif k == 2
      ds_focal_dim = ds25_taxa;
    elseif k == 3
      ds_focal_dim = ds3_taxa;
    end

    lm_scr_txTemp = fitlme(ds_focal_dim,'logSCR ~ logPrey + logPred + logAS + Taxon*Temp');
    taxa = unique(ds_focal_dim.Taxon,'stable');%Taxa in dataset in order of appearance
    temp_output = NaN(length(taxa),4); %set up a place for taxon, estimates, SEs, and pvalues

    %Pull out values for first taxon in dataset
    %temp_est = dataset2cell(ds2_taxa(1,2));
    %temp_output(i,1) = cell2mat(temp_est(2));    
    temp_est = dataset2cell(lm_scr_txTemp.Coefficients(length(taxa)+3,2)); %pull out estimate for temp
    temp_output(1,2) = cell2mat(temp_est(2));    
    temp_SE = dataset2cell(lm_scr_txTemp.Coefficients(length(taxa)+3,3)); %pull out SE for temp
    temp_output(1,3) = cell2mat(temp_SE(2)); 


        for i = 2:length(taxa)%Pull out values for other values in dataset
            temp_est = dataset2cell(lm_scr_txTemp.Coefficients(length(taxa)+3+i,2)); %pull out estimate for temp
            temp_output(i,2) = cell2mat(temp_est(2)) + temp_output(1,2);  %add estimate for first taxon to estimate of difference bw first taxon and this taxon to get estimate for this taxon
            temp_SE = dataset2cell(lm_scr_txTemp.Coefficients(length(taxa)+3+i,3)); %pull out SE for temp
            temp_output(i,3) = cell2mat(temp_SE(2)); 
            temp_pvalue = dataset2cell(lm_scr_txTemp.Coefficients(length(taxa)+3+i,6)); %pull out pvalue for whether effect of temp on this taxon is diff than effect of temp on first taxon
            temp_output(i,4) = cell2mat(temp_pvalue(2)); 
        end

        if k == 1 %separate dimensions by color and specify where to plot on y axis
            yplot = [15 16 17 18]; %plot groups from bottom up (eg first taxon is on the bottom)
            yplot2 = yplot;
            line_color = 1/255*[15 32 128];
            marker_color = 1/255*[15 32 128];
            taxa2 = taxa;
        elseif k == 2
            yplot = [11 12 13];
            yplot25 = yplot;
            line_color = 1/255*[169 90 161];
            marker_color = 1/255*[169 90 161];
            taxa25 = taxa;
        elseif k == 3        
            yplot = [1 2 3 4 5 6 7 8 9];
            yplot3 = yplot;
            line_color = 1/255*[245 121 58];
            marker_color = 1/255*[245 121 58];
            taxa3 = taxa;
        end   

       for j =1:length(taxa)
                figure(3); 
                subplot(1,3,1);%plot out estimates and SEs
                plot([temp_output(j,2)+temp_output(j,3) temp_output(j,2)-temp_output(j,3)],[yplot(j) yplot(j)],'Color',line_color,'LineWidth',2);hold on;
                plot(temp_output(j,2),yplot(j),'.','MarkerEdge',marker_color,'MarkerFace',marker_color,'MarkerSize',18); hold on;
                ylim([0 20]);
       end      
    end   
    taxa_all = [taxa3',taxa25',taxa2'];
    yplot_all = [yplot3,yplot25,yplot2];
    %xlim([-0.55 0.85]);
    ylim([0 19]);
    ax = gca; hold on; 
    ax.YTick = [yplot_all]; hold on; %add labels and tick marks
    ax.YTickLabel = taxa_all;

    xlabel('Effect of temperature');
    
     %% Interactive effects of taxon and PREDATOR mass on SPACE CLEARANCE RATE
    %Look at how mass affects different taxa differently
    Dimensions = [2 2.5 3];
    
    figure(3)
    subplot(1,3,2);
    plot([0 0],[0 19],'color',[0.5,0.5,0.5],'LineWidth',1,'LineStyle','--');hold on; %plot the dashed grey line at zero

    for k = 1:3     %Do once for each dimension

    if k == 1
      ds_focal_dim = ds2_taxa;
    elseif k == 2
      ds_focal_dim = ds25_taxa;
    elseif k == 3
      ds_focal_dim = ds3_taxa;
    end

    lm_scr_txMass = fitlme(ds_focal_dim,'logSCR ~ logPrey + Temp + logAS + Taxon*logPred') 
    taxa = unique(ds_focal_dim.Taxon,'stable');%Taxa in dataset in order of appearance
    mass_output = NaN(length(taxa),4); %set up a place for taxon, estimates, SEs, and pvalues

    %Pull out values for first taxon in dataset
    %mass_est = dataset2cell(ds2_taxa(1,2));
    %mass_output(i,1) = cell2mat(mass_est(2));    
    mass_est = dataset2cell(lm_scr_txMass.Coefficients(length(taxa)+1,2)); %pull out estimate for mass
    mass_output(1,2) = cell2mat(mass_est(2));    
    mass_SE = dataset2cell(lm_scr_txMass.Coefficients(length(taxa)+1,3)); %pull out SE for mass
    mass_output(1,3) = cell2mat(mass_SE(2)); 


        for i = 2:length(taxa)%Pull out values for other values in dataset
            mass_est = dataset2cell(lm_scr_txMass.Coefficients(length(taxa)+3+i,2)); %pull out estimate for temp
            mass_output(i,2) = cell2mat(mass_est(2)) + mass_output(1,2);  %add estimate for first taxon to estimate of difference bw first taxon and this taxon to get estimate for this taxon
            mass_SE = dataset2cell(lm_scr_txMass.Coefficients(length(taxa)+3+i,3)); %pull out SE for temp
            mass_output(i,3) = cell2mat(mass_SE(2)); 
            mass_pvalue = dataset2cell(lm_scr_txMass.Coefficients(length(taxa)+3+i,6)); %pull out pvalue for whether effect of temp on this taxon is diff than effect of temp on first taxon
            mass_output(i,4) = cell2mat(mass_pvalue(2)); 
        end

        if k == 1 %separate dimensions by color and specify where to plot on y axis
            yplot = [15 16 17 18]; %plot groups from bottom up (eg first taxon is on the bottom)
            yplot2 = yplot;
            line_color = 1/255*[15 32 128];
            marker_color = 1/255*[15 32 128];
            taxa2 = taxa;
        elseif k == 2
            yplot = [11 12 13];
            yplot25 = yplot;
            line_color = 1/255*[169 90 161];
            marker_color = 1/255*[169 90 161];
            taxa25 = taxa;
        elseif k == 3        
            yplot = [1 2 3 4 5 6 7 8 9];
            yplot3 = yplot;
            line_color = 1/255*[245 121 58];
            marker_color = 1/255*[245 121 58];
            taxa3 = taxa;
        end   

       for j =1:length(taxa)
                figure(3); 
                subplot(1,3,2);%plot out estimates and SEs
                plot([mass_output(j,2)+mass_output(j,3) mass_output(j,2)-mass_output(j,3)],[yplot(j) yplot(j)],'Color',line_color,'LineWidth',2);hold on;
                plot(mass_output(j,2),yplot(j),'.','MarkerEdge',marker_color,'MarkerFace',marker_color,'MarkerSize',18); hold on;
                ylim([0 19]);
                xlim([-1.5 4.9]);
       end      
    end   
    taxa_all = [taxa3',taxa25',taxa2'];
    yplot_all = [yplot3,yplot25,yplot2];
    ax = gca; hold on; 
    ax.YTick = [yplot_all]; hold on; %add labels and tick marks
    ax.YTickLabel = {};
    xlabel('Effect of consumer mass');    
    
         %% Interactive effects of taxon and PREY mass on SPACE CLEARANCE RATE
    %Look at how mass affects different taxa differently
    Dimensions = [2 2.5 3];
    
    figure(3)
    subplot(1,3,3);
    plot([0 0],[0 19],'color',[0.5,0.5,0.5],'LineWidth',1,'LineStyle','--');hold on; %plot the dashed grey line at zero

    for k = 1:3     %Do once for each dimension

    if k == 1
      ds_focal_dim = ds2_taxa;
    elseif k == 2
      ds_focal_dim = ds25_taxa;
    elseif k == 3
      ds_focal_dim = ds3_taxa;
    end

    lm_scr_txPrey = fitlme(ds_focal_dim,'logSCR ~ logPred + Temp + logAS + Taxon*logPrey') 
    taxa = unique(ds_focal_dim.Taxon,'stable');%Taxa in dataset in order of appearance
    mass_output = NaN(length(taxa),4); %set up a place for taxon, estimates, SEs, and pvalues

    %Pull out values for first taxon in dataset
    %mass_est = dataset2cell(ds2_taxa(1,2));
    %mass_output(i,1) = cell2mat(mass_est(2));    
    mass_est = dataset2cell(lm_scr_txPrey.Coefficients(length(taxa)+2,2)); %pull out estimate for mass
    mass_output(1,2) = cell2mat(mass_est(2));    
    mass_SE = dataset2cell(lm_scr_txPrey.Coefficients(length(taxa)+2,3)); %pull out SE for mass
    mass_output(1,3) = cell2mat(mass_SE(2)); 


        for i = 2:length(taxa)%Pull out values for other values in dataset
            mass_est = dataset2cell(lm_scr_txPrey.Coefficients(length(taxa)+3+i,2)); %pull out estimate for temp
            mass_output(i,2) = cell2mat(mass_est(2)) + mass_output(1,2);  %add estimate for first taxon to estimate of difference bw first taxon and this taxon to get estimate for this taxon
            mass_SE = dataset2cell(lm_scr_txPrey.Coefficients(length(taxa)+3+i,3)); %pull out SE for temp
            mass_output(i,3) = cell2mat(mass_SE(2)); 
            mass_pvalue = dataset2cell(lm_scr_txPrey.Coefficients(length(taxa)+3+i,6)); %pull out pvalue for whether effect of temp on this taxon is diff than effect of temp on first taxon
            mass_output(i,4) = cell2mat(mass_pvalue(2)); 
        end

        if k == 1 %separate dimensions by color and specify where to plot on y axis
            yplot = [15 16 17 18]; %plot groups from bottom up (eg first taxon is on the bottom)
            yplot2 = yplot;
            line_color = 1/255*[15 32 128];
            marker_color = 1/255*[15 32 128];
            taxa2 = taxa;
        elseif k == 2
            yplot = [11 12 13];
            yplot25 = yplot;
            line_color = 1/255*[169 90 161];
            marker_color = 1/255*[169 90 161];
            taxa25 = taxa;
        elseif k == 3        
            yplot = [1 2 3 4 5 6 7 8 9];
            yplot3 = yplot;
            line_color = 1/255*[245 121 58];
            marker_color = 1/255*[245 121 58];
            taxa3 = taxa;
        end   

       for j =1:length(taxa)
                figure(3); 
                subplot(1,3,3);%plot out estimates and SEs
                plot([mass_output(j,2)+mass_output(j,3) mass_output(j,2)-mass_output(j,3)],[yplot(j) yplot(j)],'Color',line_color,'LineWidth',2);hold on;
                plot(mass_output(j,2),yplot(j),'.','MarkerEdge',marker_color,'MarkerFace',marker_color,'MarkerSize',18); hold on;
                ylim([0 19]);
                xlim([-3.5 1]);
       end      
    end   
    taxa_all = [taxa3',taxa25',taxa2'];
    yplot_all = [yplot3,yplot25,yplot2];
    ax = gca; hold on; 
    ax.YTick = [yplot_all]; hold on; %add labels and tick marks
    ax.YTickLabel = {};
    xlabel('Effect of resource mass');   
    
    gtext('A','FontSize',12);
    gtext('B','FontSize',12);
    gtext('C','FontSize',12);
    gtext('2D','FontSize',12);
    gtext('2.5D','FontSize',12);
    gtext('3D','FontSize',12);
    
 %% Interactive effects of taxon and temperature on HANDLING TIME
    lm_ht_txTemp = fitlme(ds_taxa,'logHT ~ logPred + logPrey + Dim + Taxon*Temp') 
    %Best model with AS removed (not full column rank when AS is included, and AS is insig in best model anyway)
    
    figure(4);clf(4);
    subplot(1,3,1);
    plot([0 0],[0 19],'color',[0.5,0.5,0.5],'LineWidth',1,'LineStyle','--');hold on; %plot the dashed grey line at zero
          
    taxa = unique(ds_taxa.Taxon,'stable');%Taxa in dataset in order of appearance
    temp_output = NaN(length(taxa),4); %set up a place for taxon, estimates, SEs, and pvalues

    %Pull out values for first taxon in dataset
    %temp_est = dataset2cell(ds2_taxa(1,2));
    %temp_output(i,1) = cell2mat(temp_est(2));    
    temp_est = dataset2cell(lm_ht_txTemp.Coefficients(length(taxa)+4,2)); %pull out estimate for temp
    temp_output(1,2) = cell2mat(temp_est(2));    
    temp_SE = dataset2cell(lm_ht_txTemp.Coefficients(length(taxa)+4,3)); %pull out SE for temp
    temp_output(1,3) = cell2mat(temp_SE(2)); 

        for i = 2:length(taxa)%Pull out values for other values in dataset
            temp_est = dataset2cell(lm_ht_txTemp.Coefficients(length(taxa)+3+i,2)); %pull out estimate for temp*taxon
            temp_output(i,2) = cell2mat(temp_est(2)) + temp_output(1,2);  %add estimate for first taxon to estimate of difference bw first taxon and this taxon to get estimate for this taxon
            temp_SE = dataset2cell(lm_ht_txTemp.Coefficients(length(taxa)+3+i,3)); %pull out SE for temp*taxon
            temp_output(i,3) = cell2mat(temp_SE(2)); 
            temp_pvalue = dataset2cell(lm_ht_txTemp.Coefficients(length(taxa)+3+i,6)); %pull out pvalue for whether effect of temp on this taxon is diff than effect of temp on first taxon
            temp_output(i,4) = cell2mat(temp_pvalue(2));  
        end
        yplot = [1 2 3 4 5 6 7 8 9];
       for j =1:length(taxa)
        figure(4); 
        subplot(1,3,1);%plot out estimates and SEs
        plot([temp_output(j,2)+temp_output(j,3) temp_output(j,2)-temp_output(j,3)],[yplot(j) yplot(j)],'-b','LineWidth',2);hold on;
        plot(temp_output(j,2),yplot(j),'.b','MarkerSize',15); hold on;
        ylim([0 10]);
       end
       
    ax = gca; hold on; 
    xlim([-0.35 1.2]);
    ax.YTick = yplot; hold on; %add labels and tick marks
    ax.YTickLabel = taxa;
    xlabel('Effect of temperature');

 %% Interactive effects of taxon and PREDATOR mass on HANDLING TIME
    lm_ht_txMass = fitlme(ds_taxa,'logHT ~ Temp + logPrey + Dim + Taxon*logPred') 

    taxa = unique(ds_taxa.Taxon,'stable');%Taxa in dataset in order of appearance
    mass_output = NaN(length(taxa),4); %set up a place for taxon, estimates, SEs, and pvalues

    figure(4);
    subplot(1,3,2);
    plot([0 0],[0 19],'color',[0.5,0.5,0.5],'LineWidth',1,'LineStyle','--');hold on; %plot the dashed grey line at zero

    %Pull out values for first taxon in dataset
    %temp_est = dataset2cell(ds2_taxa(1,2));
    %temp_output(i,1) = cell2mat(mass_est(2));    
    mass_est = dataset2cell(lm_ht_txMass.Coefficients(length(taxa)+2,2)); %pull out estimate for mass
    mass_output(1,2) = cell2mat(mass_est(2));    
    mass_SE = dataset2cell(lm_ht_txMass.Coefficients(length(taxa)+2,3)); %pull out SE for mass
    mass_output(1,3) = cell2mat(mass_SE(2)); 


        for i = 2:length(taxa)%Pull out values for other values in dataset
            mass_est = dataset2cell(lm_ht_txMass.Coefficients(length(taxa)+3+i,2)); %pull out estimate for temp
            mass_output(i,2) = cell2mat(mass_est(2)) + mass_output(1,2);  %add estimate for first taxon to estimate of difference bw first taxon and this taxon to get estimate for this taxon
            mass_SE = dataset2cell(lm_ht_txMass.Coefficients(length(taxa)+3+i,3)); %pull out SE for temp
            mass_output(i,3) = cell2mat(mass_SE(2)); 
            mass_pvalue = dataset2cell(lm_ht_txMass.Coefficients(length(taxa)+3+i,6)); %pull out pvalue for whether effect of temp on this taxon is diff than effect of temp on first taxon
            mass_output(i,4) = cell2mat(mass_pvalue(2));  
        end
        yplot = [1 2 3 4 5 6 7 8 9];
       for j =1:length(taxa)
        figure(4); 
 %       subplot(1,2,2);%plot out estimates and SEs
        plot([mass_output(j,2)+mass_output(j,3) mass_output(j,2)-mass_output(j,3)],[yplot(j) yplot(j)],'-b','LineWidth',2);hold on;
        plot(mass_output(j,2),yplot(j),'.b','MarkerSize',15); hold on;
        ylim([0 10]);
       end
       
    ax = gca; hold on; 
    ax.YTick = yplot; hold on; %add labels and tick marks
    ax.YTickLabel = {};
    xlim([-0.9 1.2]);
    xlabel('Effect of consumer mass');

     %% Interactive effects of taxon and PREY mass on HANDLING TIME
    lm_ht_txPrey = fitlme(ds_taxa,'logHT ~ Temp + logPred + Dim + Taxon*logPrey') 

    taxa = unique(ds_taxa.Taxon,'stable');%Taxa in dataset in order of appearance
    mass_output = NaN(length(taxa),4); %set up a place for taxon, estimates, SEs, and pvalues

    figure(4);
    subplot(1,3,3);
    plot([0 0],[0 19],'color',[0.5,0.5,0.5],'LineWidth',1,'LineStyle','--');hold on; %plot the dashed grey line at zero

    %Pull out values for first taxon in dataset
    %temp_est = dataset2cell(ds2_taxa(1,2));
    %temp_output(i,1) = cell2mat(mass_est(2));    
    mass_est = dataset2cell(lm_ht_txPrey.Coefficients(length(taxa)+3,2)); %pull out estimate for mass
    mass_output(1,2) = cell2mat(mass_est(2));    
    mass_SE = dataset2cell(lm_ht_txPrey.Coefficients(length(taxa)+3,3)); %pull out SE for mass
    mass_output(1,3) = cell2mat(mass_SE(2)); 


        for i = 2:length(taxa)%Pull out values for other values in dataset
            mass_est = dataset2cell(lm_ht_txPrey.Coefficients(length(taxa)+3+i,2)); %pull out estimate for temp
            mass_output(i,2) = cell2mat(mass_est(2)) + mass_output(1,2);  %add estimate for first taxon to estimate of difference bw first taxon and this taxon to get estimate for this taxon
            mass_SE = dataset2cell(lm_ht_txPrey.Coefficients(length(taxa)+3+i,3)); %pull out SE for temp
            mass_output(i,3) = cell2mat(mass_SE(2)); 
            mass_pvalue = dataset2cell(lm_ht_txPrey.Coefficients(length(taxa)+3+i,6)); %pull out pvalue for whether effect of temp on this taxon is diff than effect of temp on first taxon
            mass_output(i,4) = cell2mat(mass_pvalue(2));  
        end
        yplot = [1 2 3 4 5 6 7 8 9];
       for j =1:length(taxa)
        figure(4); 
 %       subplot(1,2,2);%plot out estimates and SEs
        plot([mass_output(j,2)+mass_output(j,3) mass_output(j,2)-mass_output(j,3)],[yplot(j) yplot(j)],'-b','LineWidth',2);hold on;
        plot(mass_output(j,2),yplot(j),'.b','MarkerSize',15); hold on;
        ylim([0 10]);
       end
       
    ax = gca; hold on; 
    ax.YTick = yplot; hold on; %add labels and tick marks
    ax.YTickLabel = {};
    xlim([-0.2 1.1]);
    xlabel('Effect of resource mass');
    
    gtext('A','FontSize',12);
    gtext('B','FontSize',12);
    gtext('C','FontSize',12);